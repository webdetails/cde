defineSeed(1571, 1, makeCastMap([Q$RunAsyncCallback]));
_.onSuccess = function onSuccess_19(){
  $clinit_ContentCleanerPanel();
  this.this$0.sysAdminPanelsMap.containsKey('contentCleanerPanel') || this.this$0.sysAdminPanelsMap.put('contentCleanerPanel', instance_7);
  $passivateActiveSecurityPanels(this.this$0, 'contentCleanerPanel', null);
}
;
$entry(onLoad_0)(5);

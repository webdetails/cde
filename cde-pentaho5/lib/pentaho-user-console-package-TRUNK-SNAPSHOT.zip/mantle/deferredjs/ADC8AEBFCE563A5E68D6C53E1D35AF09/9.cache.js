defineSeed(1589, 1, makeCastMap([Q$RunAsyncCallback]));
_.onSuccess = function onSuccess_24(){
  var contentDeck;
  contentDeck = (!instance_14 && (instance_14 = new MantleXul_0) , instance_14).adminContentDeck;
  $getWidgetIndex(($clinit_MantleApplication() , !instance_6 && (instance_6 = new MantleApplication_0) , $clinit_MantleApplication() , instance_6).contentDeck, ($clinit_UserRolesAdminPanelController() , $clinit_UserRolesAdminPanelController() , instance_8)) == -1 && contentDeck.add_1(instance_8);
  contentDeck.showWidget($getWidgetIndex(contentDeck, instance_8));
}
;
$entry(onLoad_0)(9);

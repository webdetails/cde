defineSeed(1588, 1, makeCastMap([Q$RunAsyncCallback]));
_.onSuccess = function onSuccess_23(){
  var contentDeck;
  contentDeck = (!instance_14 && (instance_14 = new MantleXul_0) , instance_14).adminContentDeck;
  $getWidgetIndex(contentDeck, ($clinit_ContentCleanerPanel() , $clinit_ContentCleanerPanel() , instance_7)) == -1 && contentDeck.add_1(instance_7);
  contentDeck.showWidget($getWidgetIndex(contentDeck, instance_7));
}
;
$entry(onLoad_0)(8);

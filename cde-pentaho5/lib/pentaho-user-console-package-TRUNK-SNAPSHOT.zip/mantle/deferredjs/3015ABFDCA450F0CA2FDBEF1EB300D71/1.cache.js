defineSeed(1274, 1, makeCastMap([Q$RunAsyncCallback]));
_.onSuccess = function onSuccess_6(){
  $refresh_3(($clinit_SchedulesPerspectivePanel() , $clinit_SchedulesPerspectivePanel() , instance_17));
}
;
$entry(onLoad_0)(1);

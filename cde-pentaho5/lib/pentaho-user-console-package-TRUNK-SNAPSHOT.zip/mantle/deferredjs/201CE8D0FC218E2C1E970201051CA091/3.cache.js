defineSeed(1556, 1, makeCastMap([Q$RunAsyncCallback]));
_.onSuccess = function onSuccess_15(){
  var contentDeck;
  contentDeck = ($clinit_MantleApplication() , !instance_6 && (instance_6 = new MantleApplication_0) , $clinit_MantleApplication() , instance_6).contentDeck;
  $getWidgetIndex((!instance_6 && (instance_6 = new MantleApplication_0) , instance_6).contentDeck, ($clinit_SchedulesPerspectivePanel() , $clinit_SchedulesPerspectivePanel() , instance_17)) == -1?contentDeck.add_1(instance_17):$refresh_3(instance_17);
  contentDeck.showWidget($getWidgetIndex(contentDeck, instance_17));
}
;
$entry(onLoad_0)(3);

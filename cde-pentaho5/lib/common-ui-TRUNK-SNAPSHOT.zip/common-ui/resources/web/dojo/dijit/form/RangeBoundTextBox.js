define("dijit/form/RangeBoundTextBox", ["dojo", "dijit", "dijit/form/ValidationTextBox"], function(dojo, dijit) {



return dijit.form.RangeBoundTextBox;
});

define(
//begin v1.x content
({
	buttonOk: "Tamam",
	buttonCancel: "İptal",
	buttonSave: "Kaydet",
	itemClose: "Kapat"
})
//end v1.x content
);

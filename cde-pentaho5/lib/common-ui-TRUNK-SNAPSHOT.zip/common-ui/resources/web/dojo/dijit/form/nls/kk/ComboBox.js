define(
//begin v1.x content
({
		previousMessage: "Алдыңғы нұсқалар",
		nextMessage: "Басқа нұсқалар"
})
//end v1.x content
);


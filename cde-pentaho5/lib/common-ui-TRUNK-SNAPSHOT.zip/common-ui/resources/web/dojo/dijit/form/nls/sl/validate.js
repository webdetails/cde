define(
//begin v1.x content
({
	invalidMessage: "Vnesena vrednost ni veljavna.",
	missingMessage: "Ta vrednost je zahtevana.",
	rangeMessage: "Ta vrednost je izven območja."
})

//end v1.x content
);

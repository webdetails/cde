define(
//begin v1.x content
({
	invalidMessage: "Zadaná hodnota není platná.",
	missingMessage: "Tato hodnota je vyžadována.",
	rangeMessage: "Tato hodnota je mimo rozsah."
})
//end v1.x content
);

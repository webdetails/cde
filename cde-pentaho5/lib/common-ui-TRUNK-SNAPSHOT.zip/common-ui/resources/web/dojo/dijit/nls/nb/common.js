define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Avbryt",
	buttonSave: "Lagre",
	itemClose: "Lukk"
})
//end v1.x content
);

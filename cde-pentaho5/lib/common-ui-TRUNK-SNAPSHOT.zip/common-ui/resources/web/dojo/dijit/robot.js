define("dijit/robot", ["dojo", "dijit", "dojo/robot"], function(dojo, dijit) {



return dijit;
});

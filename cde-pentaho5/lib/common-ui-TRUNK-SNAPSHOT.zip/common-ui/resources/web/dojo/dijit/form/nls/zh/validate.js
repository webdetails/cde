define(
//begin v1.x content
({
	invalidMessage: "输入的值无效。",
	missingMessage: "此值是必需值。",
	rangeMessage: "此值超出范围。"
})
//end v1.x content
);

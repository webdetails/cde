define(
//begin v1.x content
({
		previousMessage: "先前选项",
		nextMessage: "更多选项"
})
//end v1.x content
);
